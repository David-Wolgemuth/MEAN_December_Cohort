var mongoose = require('mongoose');
console.log('future routes');

module.exports = function(app){
  //routes go here
}
